{Made by Obisoto}
This Virus is HandMade and uses .bat file so it can work only on Windows
{Name of actual virus is Obitoro V1.0.0}